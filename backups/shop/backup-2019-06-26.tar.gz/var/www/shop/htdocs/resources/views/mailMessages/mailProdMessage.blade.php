<!DOCTYPE html>
<html>
<head>
    <title>Message</title>
</head>
<body>
<p>Имя:{{$user}}</p>
<p>Email:{{$email}}</p>
<p>Сообщение:{{$msg}}</p>
<p>Кольцо:{{$name}}</p>
<p>Камень:{{$stone}}</p>
</body>
</html>