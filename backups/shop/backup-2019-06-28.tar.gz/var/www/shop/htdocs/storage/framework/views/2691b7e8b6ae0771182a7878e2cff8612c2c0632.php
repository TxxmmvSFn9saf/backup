<?php $__env->startSection('content'); ?>
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="categoryName">
            <ul class="row">
                <li class="col-lg-3 col-md-3 col-sm-3 col-xs-3 ">
                    <a href="necklacesCatalog"><h6><i class="fa fa-caret-left"></i>ОЖЕРЕЛЬЕ
                        </h6></a>
                </li>
                <li id="id_2" class="col-lg-6 col-md-6 col-sm-6 col-xs-6 ">
                    <a><h1>СЕРЕЖКИ</h1></a>


                </li>
                <li class="col-lg-3 col-md-3 col-sm-3 col-xs-3">
                    <a href="ringCatalog"><h6>КОЛЬЦА<i class="fa fa-caret-right"></i></h6>
                    </a>
                </li>
            </ul>

        </div>

        <div class="create col-lg-12 col-md-12 col-sm-12 col-xs-12" style="padding-bottom: 5px !important;">
            <?php if(Auth::check() && Auth::user()->is_admin == 1): ?>
                <a href="/createEarring/store" class="btn btn-primary btn-info">ДОБАВИТЬ</a>
            <?php endif; ?>
        </div>
        <div class="item col-lg-12 col-md-12 col-sm-12 col-xs-12">

            <?php $__currentLoopData = $earringList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                <div class="col-lg-6 col-md-6 col-sm-10 col-xs-10">
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <img class="popup_img" src="../uploads/earring/<?php echo e($item->earring_name); ?>">
                    </div>
                    <div class="catalog_about_text col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <p class="about_mob">
                            <?php
                            echo ( strlen ( "{$item->description}" ) > 300 ? substr ( "{$item->description}" , 0 , 300 ) . '...' : "{$item->description}" );
                            ?>
                        </p>
                        <p class="about_console">
                            <?php
                            echo ( strlen ( "{$item->description}" ) > 100 ? substr ( "{$item->description}" , 0 , 100 ) . '...' : "{$item->description}" );
                            ?>
                        </p>
                        <a href="<?php echo e(url('/earringCatalog/'.$item->earring_id.'/about')); ?>">ПОДРОБНЕЕ</a>


                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="price col-lg-7 col-md-7 col-sm-8 col-xs-8"><p>Цена:</p><?php echo e($item->earring_price); ?></div>
                        <div class="instock col-lg-5 col-md-5 col-sm-4 col-xs-4">
                            <?php
                            if ( "{$item->check}" == 1 ) {
                                echo '<label class="available"></label>';
                            } elseif ( "{$item->check}" == 0 ) {
                                echo '<label class="notAvailable"></label>';
                            }
                            ?>
                        </div>
                        <?php if(Auth::check() && Auth::user()->is_admin == 1): ?>
                        <?php else: ?>
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <a href="<?php echo e(url ('/earringCatalog/'.$item->earring_id.'/buy')); ?>">
                                    <button class="buybtn btn btn-info">КУПИТЬ</button>
                                </a>
                            </div>

                        <?php endif; ?>
                        <?php if(Auth::check() && Auth::user()->is_admin == 1): ?>
                            <div class=" col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <a href="<?php echo e(url('/earringCatalog/'.$item->earring_id.'/edit')); ?>">
                                    <button class="btnedit btn btn-primary btn-success">Edit</button>
                                </a>
                            </div>
                        <?php endif; ?>
                        <?php if(Auth::check() && Auth::user()->is_admin == 1): ?>
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <a href="/deleteEar/<?php echo e($item->earring_id); ?>">
                                    <button class="btndel btn btn-danger">Delete</button>
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>


                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($earringList->links()); ?>




        </div>
    </div>
    </div>
    <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>