
<footer class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <div class="copy"> Copyright &copy 2018</div>
    <div class="popupGallery">
        <div class="closeBtn">x</div>
    </div>
</footer>
</div>
<script src="<?php echo e(url ('js/script.js')); ?>"></script>

</body>
</html>
