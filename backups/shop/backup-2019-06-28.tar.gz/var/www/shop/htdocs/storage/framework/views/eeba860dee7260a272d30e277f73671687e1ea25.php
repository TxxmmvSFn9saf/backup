<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="col-lg-3 col-md-3 col-sm-4 col-xs-6">

        <img src="../uploads/necklaces/<?php echo e($item->necklace_name); ?>" class="popup_img img-thumbnail">
    </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php echo e($list->links()); ?>

