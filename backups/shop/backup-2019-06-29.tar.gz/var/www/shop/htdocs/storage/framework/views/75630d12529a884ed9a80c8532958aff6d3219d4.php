<?php $__env->startSection('content'); ?>

    <div class="container-fluid" style="margin-top: 15px;">
        <div class="row" style="margin-left: 14%;">

            <div  class="col-sm-4" style="height: 320px;">
                <?php if(isset($img->ring_name)): ?>
                    <img src="<?php echo e(asset ("/uploads/rings/{$img->ring_name}")); ?>" class="img-thumbnail">
                <?php elseif(isset($img->necklace_name)): ?>
                    <img src="<?php echo e(asset ("/uploads/necklaces/{$img->necklace_name}")); ?>" class="img-thumbnail">
                <?php elseif(isset($img->earring_name)): ?>
                    <img src="<?php echo e(asset ("/uploads/earring/{$img->earring_name}")); ?>" class="img-thumbnail">
                <?php elseif(isset($img->bracelet_name)): ?>
                    <img src="<?php echo e(asset ("/uploads/bracelets/{$img->bracelet_name}")); ?>" class="img-thumbnail">
                <?php endif; ?>
            </div>
            <div  class="col-sm-6">
                <div class="form-group" id="aboutText">
                <?php if(isset($img->description)): ?>
                        <textarea class="form-control rounded-0" id="exampleFormControlTextarea1"  rows="12"><?php echo $img->description;?></textarea>
                <?php elseif(isset($img->description)): ?>
                        <textarea class="form-control rounded-0" id="exampleFormControlTextarea1"  rows="12"><?php echo $img->description;?></textarea>
                <?php elseif(isset($img->description)): ?>
                        <textarea class="form-control rounded-0" id="exampleFormControlTextarea1"  rows="12"><?php echo $img->description;?></textarea>
                <?php elseif(isset($img->description)): ?>
                        <textarea class="form-control rounded-0" id="exampleFormControlTextarea1"  rows="12"><?php echo $img->description;?></textarea>
                <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.catalogHeader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>