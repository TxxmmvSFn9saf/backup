<!DOCTYPE html>
<html>
<head>
    <title>Message</title>
</head>
<body>
<p>Имя:{{$name}}</p>
<p>Email:{{$email}}</p>
<p>Сообщение:{{$msg}}</p>
</body>
</html>