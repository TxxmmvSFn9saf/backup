<!DOCTYPE html>
<html>
<head>
    <title>Message</title>
</head>
<body>
<p>Имя:<?php echo e($name); ?></p>
<p>Email:<?php echo e($email); ?></p>
<p>Сообщение:<?php echo e($msg); ?></p>
</body>
</html>