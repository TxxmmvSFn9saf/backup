<div class="container-fluid">
    <div class="row">
        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div id="gallery">
                <div class="col-sm-4" style="padding: 20px;">
                    <img src="../uploads/necklaces/<?php echo e($item->necklace_name); ?>" class="img-thumbnail">
                </div>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($list->links()); ?>

    </div>
    <div class="copy"> Copyright &copy 2018</div>
</div>
