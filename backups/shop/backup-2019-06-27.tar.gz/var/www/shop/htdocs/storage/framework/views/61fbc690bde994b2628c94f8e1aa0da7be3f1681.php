<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <title>EDIT</title>
    <style>body {
            background: url(<?php echo e(asset('images/background.jpg')); ?>);
            color: white;
        }</style>
</head>
<body>
<form method="post"
      <?php if(isset($edit->ring_id)): ?>
      action="<?php echo e(url('/ringCatalog/'.$edit->ring_id)); ?>"
      <?php elseif(isset($edit->bracelet_id)): ?>
      action="<?php echo e(url('/braceletCatalog/'.$edit->bracelet_id)); ?>"
      <?php elseif(isset($edit->necklace_id)): ?>
      action="<?php echo e(url('/necklacesCatalog/'.$edit->necklace_id)); ?>"
      <?php elseif(isset($edit->earring_id)): ?>
      action="<?php echo e(url('/earringCatalog/'.$edit->earring_id)); ?>"
      <?php endif; ?>
      enctype="multipart/form-data">
    <div class="form-group" style="width: 300px;">
        <?php echo e(method_field('PUT')); ?>

        <?php echo e(csrf_field()); ?>

        <input type="file" name="file" class="form-control-file"><br>
        <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token">
        <?php if(isset($edit->ring_id)): ?>
            <input type="hidden" name="ring_name" class="form-control"><br>
        <?php elseif(isset($edit->bracelet_id)): ?>
            <input type="hidden" name="bracelet_name" class="form-control"><br>
        <?php elseif(isset($edit->necklace_id)): ?>
            <input type="hidden" name="necklace_name" class="form-control"><br>
        <?php elseif(isset($edit->earring_id)): ?>
            <input type="hidden" name="earring_name" class="form-control"><br>
        <?php endif; ?>
        Description:<br>
        <input type="text" name="description" value="<?php echo e($edit->description); ?>" class="form-control">
        Price:<br>
        <?php if(isset($edit->ring_id)): ?>
            <input type="text" name="ring_price" value="<?php echo e($edit->ring_price); ?>" class="form-control"/>
        <?php elseif(isset($edit->bracelet_id)): ?>
            <input type="text" name="bracelet_price" value="<?php echo e($edit->bracelet_price); ?>" class="form-control"/>
        <?php elseif(isset($edit->necklace_id)): ?>
            <input type="text" name="necklaces_price" value="<?php echo e($edit->necklace_price); ?>" class="form-control"/>
        <?php elseif(isset($edit->earring_id)): ?>
            <input type="text" name="earring_price" value="<?php echo e($edit->earring_price); ?>" class="form-control"/>
        <?php endif; ?>
        Available:
        <input type="radio" name="check" class="form-control" value="1"/>
        Not Available:
        <input type="radio" name="check" class="form-control" value="0"/>
    </div>
    <input type="submit" value="Submit" name="save" class="btn btn-primary">
</form>

</body>
</html>
