
            <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-lg-3 col-md-3 col-sm-4 col-xs-6">

                    <img src="../uploads/earring/<?php echo e($item->earring_name); ?>" class="img-thumbnail">
                    </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($list->links()); ?>

